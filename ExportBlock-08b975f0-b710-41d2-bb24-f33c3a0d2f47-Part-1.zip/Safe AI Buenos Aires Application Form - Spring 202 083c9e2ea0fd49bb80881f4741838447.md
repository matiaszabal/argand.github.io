# Safe AI Buenos Aires Application Form - Spring 2025

Category: Grants
Page URL: https://www.notion.so/1bb883d9015a80318956e6a0ad4f7ebd
Status: Canonical