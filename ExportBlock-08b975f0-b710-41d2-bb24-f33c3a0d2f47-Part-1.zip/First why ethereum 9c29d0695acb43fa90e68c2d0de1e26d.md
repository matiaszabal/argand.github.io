# First: why ethereum?

Category: Research
Page URL: https://www.notion.so/168883d9015a80338bd9c8bf3cba1560
Status: Mixed