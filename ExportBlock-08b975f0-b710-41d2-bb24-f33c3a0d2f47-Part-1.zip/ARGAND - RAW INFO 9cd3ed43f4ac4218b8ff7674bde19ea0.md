# ARGAND - RAW INFO

Category: Reference
Page URL: https://www.notion.so/e0533ee4fe844890966d61319c5ad9da
Status: Mixed