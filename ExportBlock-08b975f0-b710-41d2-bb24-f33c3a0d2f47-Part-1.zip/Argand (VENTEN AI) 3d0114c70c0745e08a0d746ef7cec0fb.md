# Argand (VENTEN.AI)

Category: Partners
Page URL: https://www.notion.so/11b883d9015a80479a49f72c9caa7d1c
Status: Mixed