# Safe AI Buenos Aires Course - Spring 2025

Category: Programs
Page URL: https://www.notion.so/1b7883d9015a8023a693df72c5889e1c
Status: Canonical