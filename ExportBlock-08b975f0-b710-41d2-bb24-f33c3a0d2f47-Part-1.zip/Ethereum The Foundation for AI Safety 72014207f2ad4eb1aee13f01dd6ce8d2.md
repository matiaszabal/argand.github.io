# Ethereum: The Foundation for AI Safety

Category: Research
Page URL: https://www.notion.so/168883d9015a80dfb105f76a9accc6dd
Status: Mixed