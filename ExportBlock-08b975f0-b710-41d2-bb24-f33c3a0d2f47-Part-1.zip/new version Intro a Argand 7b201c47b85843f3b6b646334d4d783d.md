# new version: Intro a Argand

Category: Raw
Page URL: https://www.notion.so/1a2883d9015a806b93ddc4fb1f70b371
Status: Draft