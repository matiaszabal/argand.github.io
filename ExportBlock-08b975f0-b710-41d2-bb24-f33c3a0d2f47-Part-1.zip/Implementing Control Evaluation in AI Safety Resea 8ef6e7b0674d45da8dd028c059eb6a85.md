# Implementing Control Evaluation in AI Safety Research

Category: Research
Page URL: https://www.notion.so/1a2883d9015a8094b477dd017904c0be
Status: Mixed