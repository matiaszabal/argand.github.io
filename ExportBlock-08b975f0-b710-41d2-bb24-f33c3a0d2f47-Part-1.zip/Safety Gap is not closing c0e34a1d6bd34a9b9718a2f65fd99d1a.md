# Safety Gap is not closing

Category: Research
Page URL: https://www.notion.so/171883d9015a80a9951edee7b44d5b37
Status: Draft