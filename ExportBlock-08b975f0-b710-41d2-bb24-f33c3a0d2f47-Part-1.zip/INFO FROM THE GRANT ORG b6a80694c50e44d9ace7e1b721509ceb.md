# INFO FROM THE GRANT ORG

Category: Grants
Page URL: https://www.notion.so/1b0883d9015a811aa4fbf7fe49d31e2a
Status: Canonical