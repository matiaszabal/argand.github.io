# Proposal

Category: Strategy
Page URL: https://www.notion.so/1b0883d9015a80c68059ec22af8dd3f2
Status: Canonical