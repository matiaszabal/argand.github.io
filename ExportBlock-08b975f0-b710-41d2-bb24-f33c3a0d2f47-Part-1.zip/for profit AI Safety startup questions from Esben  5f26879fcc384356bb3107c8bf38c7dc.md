# for profit AI Safety startup questions from Esben Kran

Category: VENTEN
Page URL: https://www.notion.so/154883d9015a8096a858c779ccacfd25
Status: Mixed