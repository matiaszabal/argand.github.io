# Matias Z - AI Journey

Category: Personal
Page URL: https://www.notion.so/1b5883d9015a80d7a6f0caeb89cebfdc
Status: Mixed