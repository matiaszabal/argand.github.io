# ARTICLES ABOUT VITALIK AND AI

Category: Governance
Page URL: https://www.notion.so/15a883d9015a80af8217f6a13718863c
Status: Mixed