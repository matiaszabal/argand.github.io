# Argand Institute - AI Safety Argentina

Category: Core org
Page URL: https://www.notion.so/1af883d9015a806e8718c9b53630293e
Status: Canonical