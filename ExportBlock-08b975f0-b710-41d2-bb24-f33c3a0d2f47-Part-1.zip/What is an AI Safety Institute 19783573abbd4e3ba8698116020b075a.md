# What is an AI Safety Institute?

Category: Reference
Page URL: https://www.notion.so/1ab883d9015a8053a2b8c7b863d1157c
Status: Mixed