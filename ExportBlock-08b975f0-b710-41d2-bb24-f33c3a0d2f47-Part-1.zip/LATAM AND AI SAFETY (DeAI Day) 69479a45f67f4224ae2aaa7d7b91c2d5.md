# LATAM AND AI SAFETY (DeAI Day)

Category: Governance
Page URL: https://www.notion.so/153883d9015a8064855ccb2a321ee79f
Status: Mixed