# Argand - main concepts

Category: Reference
Page URL: https://www.notion.so/1a4883d9015a80f5897adad62f2eb69b
Status: Mixed