# le pedí criterios de AI Safety para latam

Category: VENTEN
Page URL: https://www.notion.so/1aa883d9015a80feaecffbf7621c9131
Status: Mixed